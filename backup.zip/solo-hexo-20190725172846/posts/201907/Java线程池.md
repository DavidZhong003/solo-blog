title: Java线程池
date: '2019-07-23 18:13:05'
updated: '2019-07-23 18:18:31'
tags: [Java]
permalink: /articles/2019/07/23/1563876784926.html
---
![](https://img.hacpai.com/bing/20181118.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 1. 线程池有什么作用？
- 重用线程，减少创建销毁的开销。
- 控制并发数目，避免资源抢占造成阻塞。
- 管理线程
# 2. 线程池分类？
- fixedThreadPool 固定线程池
    只有核心线程，keepAlive 0，无大小限制
- cachedThreadPool 缓存线程池
    只有非核心线程，keepAlive 60s，适用大量耗时较少任务
- scheduledThreadPool 周期线程池
    有核心和非核心线程
- singleThreadPool 单一线程池
    只有一个核心线程。
# 3. 基本执行流程？
构造方法传入核心线程数，最大线程数，存活时间，存活时间单位，任务列队，拒绝策略，线程工厂

    1. 当前线程数小于核心线程数，创建核心线程执行。
    2. 大于核心线程，任务列队未满，插入任务列队。
    3. 任务列队满了，小于最大线程数，创建非核心线程执行。
    4. 最大线程数，执行拒绝策略。
    
# 4. 源码解析

 里面通过一个int值来记录线程池状态（3位）以及当前线程数（29位）。
    
  主要方法：execute 方法，接受外界runnable对象。

    
   ```java
        public void execute(Runnable command) {
        //确保 runnable 对象不为空
        if (command == null)
            throw new NullPointerException();
        // 获取线程池状态
        int c = ctl.get();
        //1. 当当前线程数量小于核心线程数量
        if (workerCountOf(c) < corePoolSize) {
            //1.1 调用addWorker 方法，里面尝试创建线程执行command
            if (addWorker(command, true))
                return;
            // 1.2 可能添加失败则更新当前线程池状态
            c = ctl.get();
        }
        // 2. 线程数量大于核心线程
        // 2.1 确保线程池处于running 状态，尝试把任务添加到阻塞工作列队
        if (isRunning(c) && workQueue.offer(command)) {
            // 再次获取线程池状态
            int recheck = ctl.get();
            // 2.2 再次确认线程池处于running状态，如果不是则移除任务，执行拒绝策略
            if (! isRunning(recheck) && remove(command))
                reject(command);
            // 如果worker 数量为0 ，创建worker 执行任务    
            else if (workerCountOf(recheck) == 0)
                addWorker(null, false);
        }
        // 如果添加到阻塞列队失败，创建worker 执行，如果创建失败执行拒绝策略
        else if (!addWorker(command, false))
            reject(command);
    }
    ```
Worker 继承AQS（同步器） ，实现Runnable 接口。
    
    
1. addWorker方法
    
    ```java
        private boolean addWorker(Runnable firstTask, boolean core) {
        retry:
        for (;;) {
            int c = ctl.get();
            int rs = runStateOf(c);

            // Check if queue empty only if necessary.
            //检测当前状态
            //1. 线程池处于stop，tidying，terminated 状态
            //2. 线程池处于shutdown状态，列队为空
            //3. 线程池处于shutdown状态，firstTask不为空，即接受了新任务
            //以上三种情况拒绝任务
            if (rs >= SHUTDOWN &&
                ! (rs == SHUTDOWN &&
                   firstTask == null &&
                   ! workQueue.isEmpty()))
                return false;
            // 内循环
            for (;;) {
                // 获取当前线程数目
                int wc = workerCountOf(c);
                // 大于容量或者 大于核心线程（添加为核心线程时候）或最大线程数 时候返回false添加失败
                if (wc >= CAPACITY ||
                    wc >= (core ? corePoolSize : maximumPoolSize))
                    return false;
                // 没有超过大小，则增加记录线程数量，跳出循环    
                if (compareAndIncrementWorkerCount(c))
                    break retry;
                // 再次确认状态    
                c = ctl.get();  // Re-read ctl
                // 状态改变了话，重新进行循环
                if (runStateOf(c) != rs)
                    continue retry;
                // else CAS failed due to workerCount change; retry inner loop
            }
        }
        // 记录woker 启动成功标志
        boolean workerStarted = false;
        // 记录worker 添加成功标志
        boolean workerAdded = false;
        Worker w = null;
        try {
           // 构建worker
            w = new Worker(firstTask);
            final Thread t = w.thread;
            if (t != null) {
                // 获取线程池可重入锁（一个线程可锁住多次，释放多次才能完全释放）
                final ReentrantLock mainLock = this.mainLock;
                // 上锁
                mainLock.lock();
                try {
                    // 获取线程池状态
                    int rs = runStateOf(ctl.get());
                    // 线程池处于Running状态
                    // 线程池处于shutdown状态，并且还有真正执行的任务
                    if (rs < SHUTDOWN ||
                        (rs == SHUTDOWN && firstTask == null)) {
                        // 如果启动的线程活着则抛出异常
                        if (t.isAlive()) // precheck that t is startable
                            throw new IllegalThreadStateException();
                        // 添加到集合中    
                        workers.add(w);
                        // 获取线程池中线程数量
                        int s = workers.size();
                        //如果超过最大线程则更新最大值
                        if (s > largestPoolSize)
                            largestPoolSize = s;
                        workerAdded = true;
                    }
                } finally {
                    //解锁
                    mainLock.unlock();
                }
                // 一添加则启动线程
                if (workerAdded) {
                    t.start();
                    //更改标志位
                    workerStarted = true;
                }
            }
        } finally {
            if (! workerStarted)
                // 如果启动失败则执行添加失败方法
                addWorkerFailed(w);
        }
        return workerStarted;
    }
    ```
    总结：在 addWorker方法中，先检查当前线程池运行状态确保可以添加worker，然后创建worker 并且添加到workers 集合中，同时并启动worker。
    
    
2. worker run方法
    
    ```java
        执行外界的runWorker方法
        public void run() {
            runWorker(this);
        }
    ```
3. runWorker方法
    
    ```java
    final void runWorker(Worker w) {
        // 获取当前线程
        Thread wt = Thread.currentThread();
        // 获取当前任务
        Runnable task = w.firstTask;
        // 制空
        w.firstTask = null;
        // worker解锁（在创建worker时候进行加锁操作）
        w.unlock(); // allow interrupts
        //完成标志位
        boolean completedAbruptly = true;
        try {
            //worker中task 不为空或者getTask获取的任务也不为空
            while (task != null || (task = getTask()) != null) {
                // worker 上锁
                w.lock();
                
                // 如果线程池处于stop状态，确保线程被中断
                if ((runStateAtLeast(ctl.get(), STOP) ||
                     (Thread.interrupted() &&
                      runStateAtLeast(ctl.get(), STOP))) &&
                    !wt.isInterrupted())
                    wt.interrupt();
                try {
                    // 执行前调用，默认是空实现
                    beforeExecute(wt, task);
                    Throwable thrown = null;
                    try {
                        // 任务执行
                        task.run();
                    } catch (RuntimeException x) {
                        thrown = x; throw x;
                    } catch (Error x) {
                        thrown = x; throw x;
                    } catch (Throwable x) {
                        thrown = x; throw new Error(x);
                    } finally {
                        // 任务结束回调，默认空实现
                        afterExecute(task, thrown);
                    }
                } finally {
                    // task 置空，完成任务数+1，worker 解锁变成闲置worker
                    task = null;
                    w.completedTasks++;
                    w.unlock();
                }
            }
            completedAbruptly = false;
        } finally {
            //处理worker 退出（回收工作）
            processWorkerExit(w, completedAbruptly);
        }
    }
    ```
    总结：这里是真正执行外界任务的方法，期间做了线程池状态检查以及加锁，执行相关回调。
    
  3.1. getTask()方法
  
  ```java
      private Runnable getTask() {
        boolean timedOut = false; // Did the last poll() time out?

        for (;;) {
            //获取当前线程池状态
            int c = ctl.get();
            int rs = runStateOf(c);
            // 1. 当前状态不为running && 当前状态为stop之上，阻塞列队为空
            if (rs >= SHUTDOWN && (rs >= STOP || workQueue.isEmpty())) {
                // 减少worker数量
                decrementWorkerCount();
                return null;
            }
            //获取当前线程池worker 数量
            int wc = workerCountOf(c);
            // 检测是否允许超时
            boolean timed = allowCoreThreadTimeOut || wc > corePoolSize;
            // 线程池线程数量大于最大值
            // 超时没有任务返回空任务
            if ((wc > maximumPoolSize || (timed && timedOut))
                && (wc > 1 || workQueue.isEmpty())) {
                //worker数量减一
                if (compareAndDecrementWorkerCount(c))
                    return null;
                continue;
            }

            try {
                // 如果允许超时，从阻塞列队poll获取，否则take 获取（take操作也会进行阻塞）
                Runnable r = timed ?
                    workQueue.poll(keepAliveTime, TimeUnit.NANOSECONDS) :
                    workQueue.take();
                if (r != null)
                    return r;
                timedOut = true;
            } catch (InterruptedException retry) {
                timedOut = false;
            }
        }
    }
  ```
  在这个方法我们可以看见，线程会在阻塞列队中获取执行任务。结合前面的execute方法，我们可以验证线程池的执行逻辑，1.当线程池任务小于核心线程数时候，创建worker（构造方法内创建了线程）执行任务。2.当大于等于核心线程时候，把外界任务添加到阻塞列队，而这时候worker中的线程会在列队中取出任务进行执行。3. 当阻塞列队满了时候执行addWorker方法创建非核心线程执行，如果创建失败则会执行拒绝策略。
  

4. processWorkerExit()方法
上面runWorker方法分析中，最后调用了processWorkerExit方法进行worker 回收。

```java
    private void processWorkerExit(Worker w, boolean completedAbruptly) {
        // 如果没有正常结束worker
        if (completedAbruptly) // If abrupt, then workerCount wasn't adjusted
            decrementWorkerCount();
        // 上锁
        final ReentrantLock mainLock = this.mainLock;
        mainLock.lock();
        try {
            // 统计已完成的任务
            completedTaskCount += w.completedTasks;
            // 移除worker
            workers.remove(w);
        } finally {
            // 解锁
            mainLock.unlock();
        }
        //尝试关闭
        tryTerminate();
        //获取线程池状态
        int c = ctl.get();
        // 如果是running 或者shutdown状态
        if (runStateLessThan(c, STOP)) {
            //正常执行结束流程
            if (!completedAbruptly) {
                // 获取最小线程数量
                int min = allowCoreThreadTimeOut ? 0 : corePoolSize;
                if (min == 0 && ! workQueue.isEmpty())
                    min = 1;
                // 当前数量大于最小线程数量    
                if (workerCountOf(c) >= min)
                    return; // replacement not needed
            }
            // 创建新的worker 代替之前的worker
            // 1. 任务执行异常，2。worker数量少，3.阻塞列队不为空，但无worker
            addWorker(null, false);
        }
    }
```

    