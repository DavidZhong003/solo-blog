title: kotlin 中 lazy
date: '2019-07-24 18:20:42'
updated: '2019-07-24 18:54:17'
tags: [kotlin]
permalink: /articles/2019/07/24/1563963642051.html
---
今天被同事问了一个lazy的小问题：
>  LazyThreadSafetyMode 如果没有设置LazyThreadSafetyMode  by lazy默认是不是线程安全的?

答案肯定是。

先来看下lazy方法。

平常通过lazy去定义一个val类型变量是时候常常是
`val normal by lazy { "xxx" }`

其实它还有两个方法

*  `val lock by lazy(lockObj){"xxx}`
*  `val mode by lazy(LazyThreadSafetyMode.SYNCHRONIZED { "xxx" }`

那lazy方法怎么代理实现懒加载初始化一个对象的呢？它又怎么保证线程安全的呢。

---
## 实现懒初始化

* lazy(initializer: () -> T)

先看下最简单的

`public actual fun <T> lazy(initializer: () -> T): Lazy<T> = SynchronizedLazyImpl(initializer)`

可以看见把传入的初始化函数传递包装成一个SynchronizedLazyImpl对象，
而SynchronizedLazyImpl类实现Lazy接口，源码也比较简单

```kotlin

private class SynchronizedLazyImpl<out T>(initializer: () -> T, lock: Any? = null) : Lazy<T>, Serializable {
    // 懒加载闭包
    private var initializer: (() -> T)? = initializer
   // UNINITIALIZED_VALUE是一个单例对象
    @Volatile private var _value: Any? = UNINITIALIZED_VALUE
    // final field is required to enable safe publication of constructed instance
    private val lock = lock ?: this
	
    override val value: T
        get() {
            val _v1 = _value
	    // 当已经被初始化过后返回value值
            if (_v1 !== UNINITIALIZED_VALUE) {
                @Suppress("UNCHECKED_CAST")
                return _v1 as T
            }
	   // 否则进行加锁初始化		
            return synchronized(lock) {
		// 双重确定初始化
                val _v2 = _value
                if (_v2 !== UNINITIALIZED_VALUE) {
                    @Suppress("UNCHECKED_CAST") (_v2 as T)
                } else {
		   // 实际进行初始化
                    val typedValue = initializer!!()
                    _value = typedValue
                    initializer = null
                    typedValue
                }
            }
        }

    override fun isInitialized(): Boolean = _value !== UNINITIALIZED_VALUE

    override fun toString(): String = if (isInitialized()) value.toString() else "Lazy value not initialized yet."

    private fun writeReplace(): Any = InitializedLazyImpl(value)
}

```
可以看到SynchronizedLazyImpl 通过同步锁实现初始化赋值，当第一次使用lazy声明的对象的时候，通过数据委托调用Lazy 对象的_value的get方法，里面通过双重判断以及加锁执行相应的初始化。

* lazy(lock: Any?, initializer: () -> T)
源码里可以发现构建的也是SynchronizedLazyImpl 对象。

* lazy(mode: LazyThreadSafetyMode, initializer: () -> T)


里面根据不同的策略创建不同的Lazy实现对象

```
    when (mode) {
        LazyThreadSafetyMode.SYNCHRONIZED -> SynchronizedLazyImpl(initializer)
        LazyThreadSafetyMode.PUBLICATION -> SafePublicationLazyImpl(initializer)
        LazyThreadSafetyMode.NONE -> UnsafeLazyImpl(initializer)
    }
```

SynchronizedLazyImpl上面分析过了，我们就其他两种对象进行分析。

1. SafePublicationLazyImpl。

```
    override val value: T
        get() {
            val value = _value
            if (value !== UNINITIALIZED_VALUE) {
                @Suppress("UNCHECKED_CAST")
                return value as T
            }

            val initializerValue = initializer
            // if we see null in initializer here, it means that the value is already set by another thread
            if (initializerValue != null) {
                val newValue = initializerValue()
                if (valueUpdater.compareAndSet(this, UNINITIALIZED_VALUE, newValue)) {
                    initializer = null
                    return newValue
                }
            }
            @Suppress("UNCHECKED_CAST")
            return _value as T
        }
```
可以看到与SynchronizedLazyImpl不同，里面没有加同步锁，所以可以多个线程访问这些代码块，而它通过
AtomicReferenceFieldUpdater原子属性更新器更新了改类的_value值，从而保证安全修改。
2. UnsafeLazyImpl

```
    override val value: T
        get() {
            if (_value === UNINITIALIZED_VALUE) {
                _value = initializer!!()
                initializer = null
            }
            @Suppress("UNCHECKED_CAST")
            return _value as T
        }

```
这个没有加任何锁，不能保证线程安全。

