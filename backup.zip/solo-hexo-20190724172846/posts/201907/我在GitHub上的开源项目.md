title: 我在 GitHub 上的开源项目
date: '2019-07-24 17:18:45'
updated: '2019-07-24 17:18:45'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [FastApp](https://github.com/DavidZhong003/FastApp) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/DavidZhong003/FastApp/watchers "关注数")&nbsp;&nbsp;[⭐️`8`](https://github.com/DavidZhong003/FastApp/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DavidZhong003/FastApp/network/members "分叉数")&nbsp;&nbsp;[🏠`HomePage`](HomePage "项目主页")</span>

快速开发框架



---

### 2. [MyNote](https://github.com/DavidZhong003/MyNote) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/DavidZhong003/MyNote/watchers "关注数")&nbsp;&nbsp;[⭐️`5`](https://github.com/DavidZhong003/MyNote/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DavidZhong003/MyNote/network/members "分叉数")</span>





---

### 3. [Litter-Hydra2](https://github.com/DavidZhong003/Litter-Hydra2) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/DavidZhong003/Litter-Hydra2/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/DavidZhong003/Litter-Hydra2/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DavidZhong003/Litter-Hydra2/network/members "分叉数")</span>





---

### 4. [MyQuanMingTv](https://github.com/DavidZhong003/MyQuanMingTv) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/DavidZhong003/MyQuanMingTv/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/DavidZhong003/MyQuanMingTv/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DavidZhong003/MyQuanMingTv/network/members "分叉数")</span>





---

### 5. [LeetCode-kt](https://github.com/DavidZhong003/LeetCode-kt) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/DavidZhong003/LeetCode-kt/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/DavidZhong003/LeetCode-kt/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DavidZhong003/LeetCode-kt/network/members "分叉数")</span>

LeetCode刷题



---

### 6. [CalenderListView](https://github.com/DavidZhong003/CalenderListView) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/DavidZhong003/CalenderListView/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/DavidZhong003/CalenderListView/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/DavidZhong003/CalenderListView/network/members "分叉数")</span>

垂直滚动日历

